<?php

require_once ("esportazione.cfg");

$filename = "esportazione_biblioteca.xls";
$query[0] = "select Inv as Inventario, Localizzazione, Collocazione, Tipodoc as Tipo_Documento, Autore, Titolo, Luogo, Editore, Anno, Note2 as Note, ISBN, CDD, DescrizioneCDD as Descrizione_CDD from liceo";
$query[1] = "select Inv as Inventario, Localizzazione, Collocazione, Tipodoc as Tipo_Documento, Autore, Titolo, Luogo, Editore, Anno, Note2 as Note, ISBN, CDD, DescrizioneCDD as Descrizione_CDD from tecnico";
$header = "";
$data = "";
$sufinv = "PL";

foreach ($query as $val) {
	$export = mysqli_query($con,$val) or die(mysqli_error($con));

	// prima riga
	while ($fieldinfo = mysqli_fetch_field($export)) {
		$header .= $fieldinfo->name."\t";
	}

	// dati
	while ($row = mysqli_fetch_row($export)) {
		$line = '';
		foreach($row as $key=>$value) {
			if ($key==0) $value = $sufinv.$value;
			if ((!isset( $value)) || ($value == "")) {
				$value = "\t";
			} else {
				$value = str_replace('"', '""', $value);
				$value = '"'.$value . '"'."\t";
			}
			$line .= $value;
		}
		$data .= trim($line)."\n";
	}
	$data = str_replace("\r", "", $data);
	$data = utf8_encode ($data);

	if ($data == "") $data = "\nNessun record trovato.\n";

	$sufinv = "PT";
}

// forza output .xls
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=$filename");
header("Pragma: no-cache");
header("Expires: 0");
print "$header\n$data";

?>
