	<?php
	
	header('Content-type: text/html;charset=utf-8');

	define('DB_HOST', "localhost"); 
	define('DB_NAME', "biblioteca");
    define('DB_PORT', "3306"); 
    define('DB_USER', "root"); 
    define('DB_PASS', "Aleare26"); 
    
    require_once ("include/DB.class.php");
    $DB = DB::Open();
	
	function pulisci ($var) {
		$var=mysql_escape_string($var);
		$var=trim($var);
		$var=ucfirst($var);
		return $var;
	}
	
	// svuota tabelle (NO generi e prestiti)
	$tabelle=array("autori","autori_copie","copie","localizzazioni","tipi_documento","traduttori","traduttori_copie","curatori","curatori_copie","lingue","lingue_copie");
	foreach ($tabelle as $tabella){
		$q="truncate table $tabella";
		$DB->qry($q);
	}

	$cont=0;
	$handle=fopen("liceale.csv","r");
	while (($data=fgetcsv($handle,1000,","))!==FALSE){
		foreach ($data as $key=>$val) {
			$data[$key]=pulisci($val);
		}
		$cont++;	
			
		// localizzazione
		$q="select id from localizzazioni where localizzazione='$data[1]'";
		$result=$DB->qry($q);
		if ($num=$result->num_rows!=0){
			$record=$result->fetch_row();
			$id=$record[0];
			$idloc=$id;
		}else{
			$q="insert into localizzazioni (localizzazione) values('$data[1]')";
			$insert=$DB->insert($q);
			$idloc=$insert;
		}
		
		// inventario
		$ninv=5;
		$inv=$zinv="";
		$pinv=explode(" ",$data[1]);
		foreach ($pinv as $val){
			$inv.=substr($val,0,1);
		}
		$inv=strtoupper($inv);
		$nzinv=$ninv-strlen($cont);
		for ($x=1;$x<=$nzinv;$x++){
			$zinv.="0";
		}
		$inv=$inv.$zinv.$cont;

		// tipo documento
		$q="select id from tipi_documento where tipo_documento='$data[3]'";
		$result=$DB->qry($q);
		if ($num=$result->num_rows!=0){
			$record=$result->fetch_row();
			$id=$record[0];
			$idtip=$id;
		}else{
			$q="insert into tipi_documento (tipo_documento) values('$data[3]')";
			$insert=$DB->insert($q);
			$idtip=$insert;
		}
		
		// genere
		!empty($data[11]) ? $genere=substr($data[11],0,1) : $genere="-";
		
		//copia
		$q="insert into copie (inventario,id_localizzazione,collocazione,id_tipodoc,titolo,luogo,editore,anno,note,isbn,genere,cdd,descrizione_cdd,disponibile)
		               values ('$inv','$idloc','$data[2]','$idtip','$data[5]','$data[6]','$data[7]','$data[8]','$data[9]','$data[10]','$genere','$data[11]','$data[12]','1')";
		$idcopia=$DB->insert($q);
			
		// autori
		if (!empty($data[4])){
			$araut=array();
			$s=strstr($data[4],',') ? $araut=explode (',',$data[4]) : $araut[]=$data[4];
			foreach ($araut as $var){
				$var=ucwords($var);
				$q="select id from autori where autore='$var'";
				$result=$DB->qry($q);
				if ($num=$result->num_rows!=0){
					$record=$result->fetch_row();
					$id=$record[0];
					$idaut=$id;
				}else{
					$q="insert into autori (autore) values ('$var')";
					$insert=$DB->insert($q);
					$idaut=$insert;
				}
				$q="insert into autori_copie (id_autore,id_copia) values ('$idaut','$idcopia')";
				$DB->qry($q);
			}
		}
					
		// curatori
		if (!empty($data[13])){
			$arcurat=array();
			$s=strstr($data[13],',') ? $arcurat=explode (',',$data[13]) : $arcurat[]=$data[13];
			foreach ($arcurat as $var){
				$var=ucwords($var);
				$q="select id from curatori where curatore='$var'";
				$result=$DB->qry($q);
				if ($num=$result->num_rows!=0){
					$record=$result->fetch_row();
					$id=$record[0];
					$idcurat=$id;
				}else{
					$q="insert into curatori (curatore) values ('$var')";
					$insert=$DB->insert($q);
					$idcurat=$insert;
				}
				$q="insert into curatori_copie (id_curatore,id_copia) values ('$idcurat','$idcopia')";
				$DB->qry($q);
			}
		}
		
		// traduttori
		if (!empty($data[14])){
			$artrad=array();
			$s=strstr($data[14],',') ? $artrad=explode (',',$data[14]) : $artrad[]=$data[14];
			foreach ($artrad as $var){
				$var=ucwords($var);
				$q="select id from traduttori where traduttore='$var'";
				$result=$DB->qry($q);
				if ($num=$result->num_rows!=0){
					$record=$result->fetch_row();
					$id=$record[0];
					$idtrad=$id;
				}else{
					$q="insert into traduttori (traduttore) values('$var')";
					$insert=$DB->insert($q);
					$idtrad=$insert;
				}
				$q="insert into traduttori_copie (id_traduttore,id_copia) values ('$idtrad','$idcopia')";
				$DB->qry($q);
			}
		}
		
		// lingue
		if (!empty($data[15])){
			$arlin=array();
			$s=strstr($data[15],',') ? $arlin=explode (',',$data[15]) : $arlin[]=$data[15];
			foreach ($arlin as $var){
				$var=ucwords($var);
				$q="select id from lingue where lingua='$var'";
				$result=$DB->qry($q);
				if ($num=$result->num_rows!=0){
					$record=$result->fetch_row();
					$id=$record[0];
					$idlin=$id;
				}else{
					$q="insert into lingue (lingua) values('$var')";
					$insert=$DB->insert($q);
					$idlin=$insert;
				}
				$q="insert into lingue_copie (id_lingua,id_copia) values ('$idlin','$idcopia')";
				$DB->qry($q);
			}
		}
	} // end while
	fclose($handle);
	
	echo "importazione completata. $cont record inseriti.";

	
?>

	

